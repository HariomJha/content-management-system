This is a laravel based content mangagement System. 
